// Tipos para el CRM Merka 4.0

export type PipelineStage = 
  | 'PROSPECTO'
  | 'LEAD'
  | 'PROSPECTO_CALIFICADO'
  | 'PERSPECTIVA_CALIFICADA'
  | 'OFERTA_INICIAL_PRESENTADA'
  | 'PATROCINADOR_CALIFICADO'
  | 'PATROCINADOR_CON_PODER'
  | 'NEGOCIACION_ACORDADA'
  | 'EN_ESPERA_FORMALIZACION'
  | 'CONTRATO'
  | 'PERDIDA';

export type LostReason = 
  | 'PRECIO'
  | 'FALTA_CALIDAD'
  | 'FALTA_SEGUIMIENTO'
  | 'NO_APLICAMOS';

export const PIPELINE_STAGES: { key: PipelineStage; label: string; color: string }[] = [
  { key: 'PROSPECTO', label: 'Prospecto', color: '#94a3b8' },
  { key: 'LEAD', label: 'Lead', color: '#60a5fa' },
  { key: 'PROSPECTO_CALIFICADO', label: 'Prospecto Calificado', color: '#34d399' },
  { key: 'PERSPECTIVA_CALIFICADA', label: 'Perspectiva Calificada', color: '#a78bfa' },
  { key: 'OFERTA_INICIAL_PRESENTADA', label: 'Oferta Inicial Presentada', color: '#fbbf24' },
  { key: 'PATROCINADOR_CALIFICADO', label: 'Patrocinador Calificado', color: '#f472b6' },
  { key: 'PATROCINADOR_CON_PODER', label: 'Patrocinador con Poder', color: '#fb923c' },
  { key: 'NEGOCIACION_ACORDADA', label: 'Negociación Acordada', color: '#2dd4bf' },
  { key: 'EN_ESPERA_FORMALIZACION', label: 'En Espera de Formalización', color: '#818cf8' },
  { key: 'CONTRATO', label: 'Contrato', color: '#10b981' },
  { key: 'PERDIDA', label: 'Perdida', color: '#ef4444' },
];

export const LOST_REASONS: { key: LostReason; label: string }[] = [
  { key: 'PRECIO', label: 'Precio' },
  { key: 'FALTA_CALIDAD', label: 'Falta de Calidad' },
  { key: 'FALTA_SEGUIMIENTO', label: 'Falta de Seguimiento' },
  { key: 'NO_APLICAMOS', label: 'No Aplicamos' },
];

export interface Project {
  id: string;
  name: string;
  description?: string;
  color: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CustomField {
  id: string;
  projectId: string;
  name: string;
  fieldType: 'text' | 'number' | 'date' | 'select' | 'textarea';
  options?: string; // JSON string para opciones de select
  required: boolean;
  order: number;
}

export interface LeadCustomFieldValue {
  id: string;
  leadId: string;
  customFieldId: string;
  value: string;
}

export interface Lead {
  id: string;
  projectId: string;
  firstName: string;
  lastName: string;
  company?: string;
  email?: string;
  whatsapp?: string;
  description?: string;
  source: string;
  sourceDetails?: string;
  stage: PipelineStage;
  lostReason?: LostReason;
  lostNotes?: string;
  lostAt?: string;
  estimatedValue?: number;
  notes?: string;
  lastContactAt?: string;
  nextFollowUpAt?: string;
  createdAt: string;
  updatedAt: string;
  customFieldValues?: LeadCustomFieldValue[];
}

export interface Activity {
  id: string;
  leadId: string;
  type: 'call' | 'email' | 'meeting' | 'note' | 'stage_change';
  description: string;
  metadata?: string;
  createdAt: string;
}

export interface LeadWithExtras extends Lead {
  customFieldValues?: LeadCustomFieldValue[];
  activities?: Activity[];
}

export interface CreateLeadInput {
  projectId: string;
  firstName: string;
  lastName: string;
  company?: string;
  email?: string;
  whatsapp?: string;
  description?: string;
  source?: string;
  sourceDetails?: string;
  estimatedValue?: number;
  notes?: string;
  customFields?: { fieldId: string; value: string }[];
}

export interface UpdateLeadInput {
  firstName?: string;
  lastName?: string;
  company?: string;
  email?: string;
  whatsapp?: string;
  description?: string;
  stage?: PipelineStage;
  lostReason?: LostReason;
  lostNotes?: string;
  estimatedValue?: number;
  notes?: string;
  lastContactAt?: string;
  nextFollowUpAt?: string;
  customFields?: { fieldId: string; value: string }[];
}
