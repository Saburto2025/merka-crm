import { create } from 'zustand';
import type { Project, Lead, CustomField, PipelineStage } from '@/types/crm';

interface CRMState {
  // Proyecto actual
  currentProject: Project | null;
  projects: Project[];
  
  // Leads
  leads: Lead[];
  
  // Campos personalizados
  customFields: CustomField[];
  
  // UI State
  isLoading: boolean;
  sidebarOpen: boolean;
  leadDialogOpen: boolean;
  selectedLead: Lead | null;
  lostDialogOpen: boolean;
  
  // Filters
  searchQuery: string;
  stageFilter: PipelineStage | 'all';
  
  // Actions
  setCurrentProject: (project: Project | null) => void;
  setProjects: (projects: Project[]) => void;
  setLeads: (leads: Lead[]) => void;
  setCustomFields: (fields: CustomField[]) => void;
  setLoading: (loading: boolean) => void;
  setSidebarOpen: (open: boolean) => void;
  setLeadDialogOpen: (open: boolean) => void;
  setSelectedLead: (lead: Lead | null) => void;
  setLostDialogOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  setStageFilter: (stage: PipelineStage | 'all') => void;
  
  // CRUD Operations
  addLead: (lead: Lead) => void;
  updateLead: (id: string, data: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  
  addProject: (project: Project) => void;
  updateProject: (id: string, data: Partial<Project>) => void;
  deleteProject: (id: string) => void;
}

export const useCRMStore = create<CRMState>((set) => ({
  // Initial state
  currentProject: null,
  projects: [],
  leads: [],
  customFields: [],
  isLoading: false,
  sidebarOpen: true,
  leadDialogOpen: false,
  selectedLead: null,
  lostDialogOpen: false,
  searchQuery: '',
  stageFilter: 'all',
  
  // Setters
  setCurrentProject: (project) => set({ currentProject: project }),
  setProjects: (projects) => set({ projects }),
  setLeads: (leads) => set({ leads }),
  setCustomFields: (fields) => set({ customFields: fields }),
  setLoading: (loading) => set({ isLoading: loading }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setLeadDialogOpen: (open) => set({ leadDialogOpen: open }),
  setSelectedLead: (lead) => set({ selectedLead: lead }),
  setLostDialogOpen: (open) => set({ lostDialogOpen: open }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setStageFilter: (stage) => set({ stageFilter: stage }),
  
  // CRUD Lead
  addLead: (lead) => set((state) => ({ leads: [...state.leads, lead] })),
  updateLead: (id, data) => set((state) => ({
    leads: state.leads.map((lead) => 
      lead.id === id ? { ...lead, ...data } : lead
    )
  })),
  deleteLead: (id) => set((state) => ({
    leads: state.leads.filter((lead) => lead.id !== id)
  })),
  
  // CRUD Project
  addProject: (project) => set((state) => ({ projects: [...state.projects, project] })),
  updateProject: (id, data) => set((state) => ({
    projects: state.projects.map((project) => 
      project.id === id ? { ...project, ...data } : project
    )
  })),
  deleteProject: (id) => set((state) => ({
    projects: state.projects.filter((project) => project.id !== id)
  })),
}));
