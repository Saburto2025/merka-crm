'use client';

import { useState, useEffect, useCallback } from 'react';
import { useCRMStore } from '@/store/crm-store';
import { 
  PIPELINE_STAGES, 
  LOST_REASONS, 
  type Lead, 
  type Project,
  type PipelineStage,
  type LostReason as LostReasonType,
  type CustomField
} from '@/types/crm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragStartEvent,
  DragEndEvent,
  DragOverEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  Plus,
  Search,
  Building2,
  Mail,
  Phone,
  MessageCircle,
  MoreVertical,
  Trash2,
  Edit,
  Download,
  Upload,
  FolderPlus,
  Settings,
  ChevronLeft,
  ChevronRight,
  GripVertical,
  DollarSign,
  Calendar,
  FileText,
  AlertCircle,
  CheckCircle,
  XCircle,
  ExternalLink,
  Eye,
  Move,
} from 'lucide-react';
import { toast } from 'sonner';
import { CustomFieldManager } from '@/components/crm/custom-field-manager';

// Draggable Lead Card Component
interface LeadCardProps {
  lead: Lead;
  isDragging?: boolean;
  onView: (lead: Lead) => void;
  onEdit: (lead: Lead) => void;
  onDelete: (leadId: string) => void;
  onStageChange: (lead: Lead, stage: PipelineStage) => void;
}

function DraggableLeadCard({ lead, isDragging, onView, onEdit, onDelete, onStageChange }: LeadCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging,
  } = useSortable({ id: lead.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isSortableDragging ? 0.5 : 1,
  };

  const stageInfo = PIPELINE_STAGES.find(s => s.key === lead.stage);
  
  return (
    <Card 
      ref={setNodeRef} 
      style={style}
      className={`group cursor-pointer hover:shadow-md transition-all duration-200 border-l-4 ${
        isDragging ? 'shadow-lg ring-2 ring-emerald-500' : ''
      }`}
    >
      <CardContent className="p-3">
        <div className="flex items-start justify-between gap-2">
          <div 
            className="flex items-center gap-2 cursor-grab active:cursor-grabbing"
            {...attributes}
            {...listeners}
          >
            <GripVertical className="h-4 w-4 text-slate-300 hover:text-slate-500 transition-colors" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-sm truncate">
              {lead.firstName} {lead.lastName}
            </h4>
            {lead.company && (
              <p className="text-xs text-muted-foreground truncate flex items-center gap-1 mt-0.5">
                <Building2 className="h-3 w-3" />
                {lead.company}
              </p>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreVertical className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onView(lead)}>
                <Eye className="h-4 w-4 mr-2" />
                Ver detalles
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEdit(lead)}>
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => onDelete(lead.id)}
                className="text-destructive"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Eliminar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="flex flex-wrap gap-1 mt-2">
          {lead.email && (
            <Badge variant="secondary" className="text-xs">
              <Mail className="h-3 w-3 mr-1" />
              Email
            </Badge>
          )}
          {lead.whatsapp && (
            <Badge variant="secondary" className="text-xs">
              <MessageCircle className="h-3 w-3 mr-1" />
              WhatsApp
            </Badge>
          )}
        </div>
        
        {lead.estimatedValue && (
          <p className="text-xs font-medium text-emerald-600 mt-2">
            ${lead.estimatedValue.toLocaleString()}
          </p>
        )}
        
        {lead.source === 'whatsapp' && (
          <Badge variant="outline" className="mt-2 text-xs bg-green-50 text-green-700 border-green-200">
            Fuente: WhatsApp
          </Badge>
        )}
        
        {lead.stage === 'PERDIDA' && lead.lostReason && (
          <div className="mt-2 p-2 bg-red-50 rounded text-xs">
            <p className="font-medium text-red-700">
              {LOST_REASONS.find(r => r.key === lead.lostReason)?.label}
            </p>
            {lead.lostNotes && (
              <p className="text-red-600 mt-1 truncate">{lead.lostNotes}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Droppable Column Component
interface PipelineColumnProps {
  stage: { key: PipelineStage; label: string; color: string };
  leads: Lead[];
  onDragOver?: (event: DragOverEvent) => void;
}

function PipelineColumn({ stage, leads }: PipelineColumnProps) {
  const { setNodeRef } = useSortable({ id: stage.key });
  
  return (
    <div className="w-72 flex-shrink-0" ref={setNodeRef}>
      {/* Stage Header */}
      <div 
        className="rounded-t-lg p-3 flex items-center justify-between"
        style={{ backgroundColor: `${stage.color}20` }}
      >
        <div className="flex items-center gap-2">
          <div 
            className="h-3 w-3 rounded-full"
            style={{ backgroundColor: stage.color }}
          />
          <h3 className="font-medium text-sm" style={{ color: stage.color }}>
            {stage.label}
          </h3>
        </div>
        <Badge 
          variant="secondary" 
          className="text-xs"
          style={{ backgroundColor: `${stage.color}30`, color: stage.color }}
        >
          {leads.length}
        </Badge>
      </div>
      
      {/* Stage Content */}
      <div 
        className="rounded-b-lg p-2 min-h-[200px]"
        style={{ backgroundColor: `${stage.color}05` }}
      >
        <SortableContext items={leads.map(l => l.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {leads.map((lead) => (
              <DraggableLeadCard 
                key={lead.id} 
                lead={lead}
                onView={() => {}}
                onEdit={() => {}}
                onDelete={() => {}}
                onStageChange={() => {}}
              />
            ))}
          </div>
        </SortableContext>
        
        {leads.length === 0 && (
          <div className="text-center py-8 text-slate-400 text-sm">
            Sin leads en esta etapa
          </div>
        )}
      </div>
    </div>
  );
}

export default function MerkaCRM() {
  const {
    currentProject,
    projects,
    leads,
    isLoading,
    searchQuery,
    setCurrentProject,
    setProjects,
    setLeads,
    setLoading,
    addLead,
    updateLead,
    deleteLead,
    addProject,
    setSearchQuery,
  } = useCRMStore();

  // Estados locales para diálogos
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);
  const [leadDialogOpen, setLeadDialogOpen] = useState(false);
  const [editLeadDialogOpen, setEditLeadDialogOpen] = useState(false);
  const [lostDialogOpen, setLostDialogOpen] = useState(false);
  const [viewLeadDialogOpen, setViewLeadDialogOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [pendingStageChange, setPendingStageChange] = useState<{ lead: Lead; newStage: PipelineStage } | null>(null);
  
  // Estados para formularios
  const [projectForm, setProjectForm] = useState({ name: '', description: '', color: '#10b981' });
  const [leadForm, setLeadForm] = useState({
    firstName: '',
    lastName: '',
    company: '',
    email: '',
    whatsapp: '',
    description: '',
    source: 'manual',
    estimatedValue: '',
    notes: '',
  });
  const [lostForm, setLostForm] = useState({ reason: '' as LostReasonType | '', notes: '' });
  
  // Campos personalizados
  const [customFields, setCustomFields] = useState<CustomField[]>([]);
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, string>>({});
  
  // DnD State
  const [activeLead, setActiveLead] = useState<Lead | null>(null);
  const [overId, setOverId] = useState<string | null>(null);
  
  // DnD Sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );
  
  // Cargar proyectos al inicio
  useEffect(() => {
    loadProjects();
  }, []);

  // Cargar leads cuando cambia el proyecto actual
  useEffect(() => {
    if (currentProject) {
      loadLeads(currentProject.id);
      loadCustomFields(currentProject.id);
    }
  }, [currentProject]);

  const loadProjects = async () => {
    try {
      const response = await fetch('/api/projects');
      const data = await response.json();
      setProjects(data);
      
      if (!currentProject && data.length > 0) {
        setCurrentProject(data[0]);
      }
    } catch (error) {
      console.error('Error loading projects:', error);
      toast.error('Error al cargar proyectos');
    }
  };

  const loadLeads = async (projectId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/leads?projectId=${projectId}`);
      const data = await response.json();
      setLeads(data);
    } catch (error) {
      console.error('Error loading leads:', error);
      toast.error('Error al cargar leads');
    } finally {
      setLoading(false);
    }
  };

  const loadCustomFields = async (projectId: string) => {
    try {
      const response = await fetch(`/api/projects/${projectId}/custom-fields`);
      const data = await response.json();
      setCustomFields(data);
    } catch (error) {
      console.error('Error loading custom fields:', error);
    }
  };

  // Crear proyecto
  const handleCreateProject = async () => {
    if (!projectForm.name.trim()) {
      toast.error('El nombre del proyecto es requerido');
      return;
    }

    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectForm),
      });
      
      if (response.ok) {
        const newProject = await response.json();
        addProject(newProject);
        setCurrentProject(newProject);
        setProjectDialogOpen(false);
        setProjectForm({ name: '', description: '', color: '#10b981' });
        toast.success('Proyecto creado exitosamente');
      }
    } catch (error) {
      console.error('Error creating project:', error);
      toast.error('Error al crear proyecto');
    }
  };

  // Crear lead
  const handleCreateLead = async () => {
    if (!currentProject) {
      toast.error('Selecciona un proyecto primero');
      return;
    }

    if (!leadForm.firstName.trim() || !leadForm.lastName.trim()) {
      toast.error('Nombre y apellido son requeridos');
      return;
    }

    try {
      const customFieldsData = Object.entries(customFieldValues).map(([fieldId, value]) => ({
        fieldId,
        value,
      }));

      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...leadForm,
          projectId: currentProject.id,
          estimatedValue: leadForm.estimatedValue ? parseFloat(leadForm.estimatedValue) : undefined,
          customFields: customFieldsData,
        }),
      });
      
      if (response.ok) {
        const newLead = await response.json();
        addLead(newLead);
        setLeadDialogOpen(false);
        setLeadForm({
          firstName: '',
          lastName: '',
          company: '',
          email: '',
          whatsapp: '',
          description: '',
          source: 'manual',
          estimatedValue: '',
          notes: '',
        });
        setCustomFieldValues({});
        toast.success('Lead creado exitosamente');
      }
    } catch (error) {
      console.error('Error creating lead:', error);
      toast.error('Error al crear lead');
    }
  };

  // Editar lead
  const handleEditLead = async () => {
    if (!selectedLead) return;
    
    try {
      const response = await fetch(`/api/leads/${selectedLead.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...leadForm,
          estimatedValue: leadForm.estimatedValue ? parseFloat(leadForm.estimatedValue) : null,
        }),
      });
      
      if (response.ok) {
        const updatedLead = await response.json();
        updateLead(selectedLead.id, updatedLead);
        setEditLeadDialogOpen(false);
        setSelectedLead(null);
        toast.success('Lead actualizado');
      }
    } catch (error) {
      console.error('Error updating lead:', error);
      toast.error('Error al actualizar lead');
    }
  };

  // Cambiar etapa de lead
  const handleStageChange = useCallback(async (lead: Lead, newStage: PipelineStage) => {
    if (newStage === 'PERDIDA') {
      setPendingStageChange({ lead, newStage });
      setLostDialogOpen(true);
    } else {
      try {
        const response = await fetch(`/api/leads/${lead.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stage: newStage }),
        });
        
        if (response.ok) {
          const updatedLead = await response.json();
          updateLead(lead.id, updatedLead);
          toast.success('Etapa actualizada');
        }
      } catch (error) {
        console.error('Error updating stage:', error);
        toast.error('Error al actualizar etapa');
      }
    }
  }, [updateLead]);

  // Confirmar pérdida
  const handleConfirmLost = async () => {
    if (!pendingStageChange || !lostForm.reason) {
      toast.error('Selecciona una razón de pérdida');
      return;
    }

    try {
      const response = await fetch(`/api/leads/${pendingStageChange.lead.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stage: 'PERDIDA',
          lostReason: lostForm.reason,
          lostNotes: lostForm.notes,
        }),
      });
      
      if (response.ok) {
        const updatedLead = await response.json();
        updateLead(pendingStageChange.lead.id, updatedLead);
        setLostDialogOpen(false);
        setLostForm({ reason: '', notes: '' });
        setPendingStageChange(null);
        toast.success('Lead marcado como perdido');
      }
    } catch (error) {
      console.error('Error marking lead as lost:', error);
      toast.error('Error al marcar lead como perdido');
    }
  };

  // Eliminar lead
  const handleDeleteLead = async (leadId: string) => {
    if (!confirm('¿Estás seguro de eliminar este lead?')) return;

    try {
      const response = await fetch(`/api/leads/${leadId}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        deleteLead(leadId);
        toast.success('Lead eliminado');
      }
    } catch (error) {
      console.error('Error deleting lead:', error);
      toast.error('Error al eliminar lead');
    }
  };

  // Exportar CSV
  const handleExport = async () => {
    if (!currentProject) return;
    
    try {
      const response = await fetch(`/api/export?projectId=${currentProject.id}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `merka-leads-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('Datos exportados exitosamente');
    } catch (error) {
      console.error('Error exporting:', error);
      toast.error('Error al exportar datos');
    }
  };

  // Importar CSV
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !currentProject) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('projectId', currentProject.id);

    try {
      const response = await fetch('/api/import', {
        method: 'POST',
        body: formData,
      });
      
      const result = await response.json();
      if (result.success) {
        toast.success(`Importados ${result.imported} leads. Errores: ${result.errors}`);
        loadLeads(currentProject.id);
      }
    } catch (error) {
      console.error('Error importing:', error);
      toast.error('Error al importar datos');
    }
    
    event.target.value = '';
  };

  // DnD Handlers
  const handleDragStart = (event: DragStartEvent) => {
    const leadId = event.active.id as string;
    const lead = leads.find(l => l.id === leadId);
    setActiveLead(lead || null);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { over } = event;
    setOverId(over?.id as string || null);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && activeLead) {
      const newStage = over.id as PipelineStage;
      
      // Check if over a column (stage) or another lead
      const isStage = PIPELINE_STAGES.some(s => s.key === over.id);
      
      if (isStage && newStage !== activeLead.stage) {
        handleStageChange(activeLead, newStage);
      }
    }
    
    setActiveLead(null);
    setOverId(null);
  };

  // Filtrar leads por búsqueda
  const filteredLeads = leads.filter(lead => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      lead.firstName.toLowerCase().includes(query) ||
      lead.lastName.toLowerCase().includes(query) ||
      lead.company?.toLowerCase().includes(query) ||
      lead.email?.toLowerCase().includes(query)
    );
  });

  // Agrupar leads por etapa
  const leadsByStage = PIPELINE_STAGES.reduce((acc, stage) => {
    acc[stage.key] = filteredLeads.filter(lead => lead.stage === stage.key);
    return acc;
  }, {} as Record<PipelineStage, Lead[]>);

  // Calcular valor total del pipeline
  const totalPipelineValue = filteredLeads
    .filter(l => l.stage !== 'PERDIDA')
    .reduce((sum, lead) => sum + (lead.estimatedValue || 0), 0);

  // Handlers for lead card actions
  const handleViewLead = (lead: Lead) => {
    setSelectedLead(lead);
    setViewLeadDialogOpen(true);
  };

  const handleEditLeadClick = (lead: Lead) => {
    setSelectedLead(lead);
    setLeadForm({
      firstName: lead.firstName,
      lastName: lead.lastName,
      company: lead.company || '',
      email: lead.email || '',
      whatsapp: lead.whatsapp || '',
      description: lead.description || '',
      source: lead.source,
      estimatedValue: lead.estimatedValue?.toString() || '',
      notes: lead.notes || '',
    });
    setEditLeadDialogOpen(true);
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
          <div className="max-w-full mx-auto px-4 py-3">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md">
                  <span className="text-white font-bold text-lg">M</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">Merka 4.0 CRM</h1>
                  <p className="text-xs text-slate-500">Gestión profesional de leads y ventas</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Selector de proyecto */}
                <Select
                  value={currentProject?.id || ''}
                  onValueChange={(value) => {
                    const project = projects.find(p => p.id === value);
                    if (project) setCurrentProject(project);
                  }}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Seleccionar proyecto" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((project) => (
                      <SelectItem key={project.id} value={project.id}>
                        <div className="flex items-center gap-2">
                          <div 
                            className="h-2 w-2 rounded-full" 
                            style={{ backgroundColor: project.color }}
                          />
                          {project.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button size="sm" variant="outline" onClick={() => setProjectDialogOpen(true)}>
                  <FolderPlus className="h-4 w-4 mr-1" />
                  Nuevo Proyecto
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Toolbar */}
        <div className="bg-white border-b border-slate-200 px-4 py-2">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Buscar leads..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {currentProject && (
                <CustomFieldManager 
                  projectId={currentProject.id} 
                  onFieldsChange={() => loadCustomFields(currentProject.id)}
                />
              )}
              <Button size="sm" variant="outline" onClick={handleExport} disabled={!currentProject}>
                <Download className="h-4 w-4 mr-1" />
                Exportar CSV
              </Button>
              
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleImport}
                  className="hidden"
                  disabled={!currentProject}
                />
                <Button size="sm" variant="outline" asChild disabled={!currentProject}>
                  <span>
                    <Upload className="h-4 w-4 mr-1" />
                    Importar CSV
                  </span>
                </Button>
              </label>
              
              <Button 
                size="sm" 
                onClick={() => {
                  setLeadForm({
                    firstName: '',
                    lastName: '',
                    company: '',
                    email: '',
                    whatsapp: '',
                    description: '',
                    source: 'manual',
                    estimatedValue: '',
                    notes: '',
                  });
                  setLeadDialogOpen(true);
                }}
                disabled={!currentProject}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Nuevo Lead
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="bg-white border-b border-slate-200 px-4 py-2">
          <div className="flex items-center gap-6 text-sm flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Total Leads:</span>
              <Badge variant="secondary">{filteredLeads.length}</Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Pipeline Activo:</span>
              <Badge className="bg-emerald-100 text-emerald-700">
                {filteredLeads.filter(l => l.stage !== 'PERDIDA').length}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Valor Pipeline:</span>
              <Badge className="bg-blue-100 text-blue-700">
                ${totalPipelineValue.toLocaleString()}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500">Perdidos:</span>
              <Badge className="bg-red-100 text-red-700">
                {filteredLeads.filter(l => l.stage === 'PERDIDA').length}
              </Badge>
            </div>
            <div className="ml-auto text-slate-400 text-xs">
              <Move className="h-3 w-3 inline mr-1" />
              Arrastra los leads entre etapas
            </div>
          </div>
        </div>

        {/* Main Content - Kanban Board */}
        <main className="flex-1 overflow-hidden">
          {!currentProject ? (
            <div className="h-full flex items-center justify-center">
              <Card className="max-w-md mx-4">
                <CardContent className="pt-6 text-center">
                  <FolderPlus className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No hay proyectos</h3>
                  <p className="text-slate-500 mb-4">
                    Crea tu primer proyecto para comenzar a gestionar leads
                  </p>
                  <Button onClick={() => setProjectDialogOpen(true)} className="bg-emerald-600 hover:bg-emerald-700">
                    <FolderPlus className="h-4 w-4 mr-2" />
                    Crear Proyecto
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : isLoading ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-4" />
                <p className="text-slate-500">Cargando leads...</p>
              </div>
            </div>
          ) : (
            <ScrollArea className="h-full">
              <div className="p-4">
                <div className="flex gap-4 pb-4" style={{ minWidth: 'max-content' }}>
                  {PIPELINE_STAGES.map((stage) => (
                    <div
                      key={stage.key}
                      className={`w-72 flex-shrink-0 transition-all duration-200 ${
                        overId === stage.key ? 'ring-2 ring-emerald-400 rounded-lg' : ''
                      }`}
                    >
                      {/* Stage Header */}
                      <div 
                        className="rounded-t-lg p-3 flex items-center justify-between"
                        style={{ backgroundColor: `${stage.color}20` }}
                      >
                        <div className="flex items-center gap-2">
                          <div 
                            className="h-3 w-3 rounded-full"
                            style={{ backgroundColor: stage.color }}
                          />
                          <h3 className="font-medium text-sm" style={{ color: stage.color }}>
                            {stage.label}
                          </h3>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className="text-xs"
                          style={{ backgroundColor: `${stage.color}30`, color: stage.color }}
                        >
                          {leadsByStage[stage.key]?.length || 0}
                        </Badge>
                      </div>
                      
                      {/* Stage Content */}
                      <div 
                        className="rounded-b-lg p-2 min-h-[200px]"
                        style={{ backgroundColor: `${stage.color}05` }}
                      >
                        <SortableContext items={leadsByStage[stage.key]?.map(l => l.id) || []} strategy={verticalListSortingStrategy}>
                          <div className="space-y-2">
                            {leadsByStage[stage.key]?.map((lead) => (
                              <DraggableLeadCard 
                                key={lead.id} 
                                lead={lead}
                                onView={handleViewLead}
                                onEdit={handleEditLeadClick}
                                onDelete={handleDeleteLead}
                                onStageChange={handleStageChange}
                              />
                            ))}
                          </div>
                        </SortableContext>
                        
                        {leadsByStage[stage.key]?.length === 0 && (
                          <div className="text-center py-8 text-slate-400 text-sm">
                            Sin leads en esta etapa
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollArea>
          )}
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-slate-200 px-4 py-3 mt-auto">
          <div className="flex items-center justify-between text-sm text-slate-500 flex-wrap gap-2">
            <p>Merka 4.0 CRM - Gestión profesional de leads y ventas</p>
            <p>
              WhatsApp: {' '}
              <a 
                href="https://wa.me/50664498045" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-emerald-600 hover:underline flex items-center gap-1"
              >
                <MessageCircle className="h-4 w-4" />
                +506 6449 8045
                <ExternalLink className="h-3 w-3" />
              </a>
            </p>
          </div>
        </footer>

        {/* Drag Overlay */}
        <DragOverlay>
          {activeLead && (
            <Card className="shadow-xl ring-2 ring-emerald-500 border-l-4 w-64" style={{ borderLeftColor: PIPELINE_STAGES.find(s => s.key === activeLead.stage)?.color }}>
              <CardContent className="p-3">
                <h4 className="font-medium text-sm">
                  {activeLead.firstName} {activeLead.lastName}
                </h4>
                {activeLead.company && (
                  <p className="text-xs text-muted-foreground truncate flex items-center gap-1 mt-0.5">
                    <Building2 className="h-3 w-3" />
                    {activeLead.company}
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </DragOverlay>

        {/* Dialog: Nuevo Proyecto */}
        <Dialog open={projectDialogOpen} onOpenChange={setProjectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crear Nuevo Proyecto</DialogTitle>
              <DialogDescription>
                Crea un nuevo proyecto para gestionar leads de forma aislada
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="projectName">Nombre del Proyecto *</Label>
                <Input
                  id="projectName"
                  value={projectForm.name}
                  onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })}
                  placeholder="Ej: Mi Empresa S.A."
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="projectDesc">Descripción</Label>
                <Textarea
                  id="projectDesc"
                  value={projectForm.description}
                  onChange={(e) => setProjectForm({ ...projectForm, description: e.target.value })}
                  placeholder="Descripción opcional del proyecto"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="projectColor">Color</Label>
                <div className="flex gap-2">
                  {['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899'].map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setProjectForm({ ...projectForm, color })}
                      className={`h-8 w-8 rounded-full transition-all ${
                        projectForm.color === color ? 'ring-2 ring-offset-2 ring-slate-400' : ''
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setProjectDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreateProject} className="bg-emerald-600 hover:bg-emerald-700">
                Crear Proyecto
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog: Nuevo Lead */}
        <Dialog open={leadDialogOpen} onOpenChange={setLeadDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nuevo Lead</DialogTitle>
              <DialogDescription>
                Ingresa los datos del nuevo lead
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">Nombre *</Label>
                  <Input
                    id="firstName"
                    value={leadForm.firstName}
                    onChange={(e) => setLeadForm({ ...leadForm, firstName: e.target.value })}
                    placeholder="Nombre"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Apellido *</Label>
                  <Input
                    id="lastName"
                    value={leadForm.lastName}
                    onChange={(e) => setLeadForm({ ...leadForm, lastName: e.target.value })}
                    placeholder="Apellido"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  value={leadForm.company}
                  onChange={(e) => setLeadForm({ ...leadForm, company: e.target.value })}
                  placeholder="Nombre de la empresa"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={leadForm.email}
                    onChange={(e) => setLeadForm({ ...leadForm, email: e.target.value })}
                    placeholder="correo@ejemplo.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp</Label>
                  <Input
                    id="whatsapp"
                    value={leadForm.whatsapp}
                    onChange={(e) => setLeadForm({ ...leadForm, whatsapp: e.target.value })}
                    placeholder="+506 0000 0000"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={leadForm.description}
                  onChange={(e) => setLeadForm({ ...leadForm, description: e.target.value })}
                  placeholder="Descripción del lead o su interés"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="source">Fuente</Label>
                  <Select
                    value={leadForm.source}
                    onValueChange={(value) => setLeadForm({ ...leadForm, source: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="referral">Referido</SelectItem>
                      <SelectItem value="website">Sitio Web</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="other">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="estimatedValue">Valor Estimado ($)</Label>
                  <Input
                    id="estimatedValue"
                    type="number"
                    value={leadForm.estimatedValue}
                    onChange={(e) => setLeadForm({ ...leadForm, estimatedValue: e.target.value })}
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notas Adicionales</Label>
                <Textarea
                  id="notes"
                  value={leadForm.notes}
                  onChange={(e) => setLeadForm({ ...leadForm, notes: e.target.value })}
                  placeholder="Notas adicionales sobre el lead"
                  rows={2}
                />
              </div>
              
              {/* Campos personalizados */}
              {customFields.length > 0 && (
                <>
                  <Separator />
                  <h4 className="font-medium text-sm">Campos Personalizados</h4>
                  <div className="grid grid-cols-2 gap-4">
                    {customFields.map((field) => (
                      <div key={field.id} className="space-y-2">
                        <Label htmlFor={`custom-${field.id}`}>
                          {field.name}
                          {field.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                        {field.fieldType === 'text' && (
                          <Input
                            id={`custom-${field.id}`}
                            value={customFieldValues[field.id] || ''}
                            onChange={(e) => setCustomFieldValues({
                              ...customFieldValues,
                              [field.id]: e.target.value
                            })}
                          />
                        )}
                        {field.fieldType === 'number' && (
                          <Input
                            id={`custom-${field.id}`}
                            type="number"
                            value={customFieldValues[field.id] || ''}
                            onChange={(e) => setCustomFieldValues({
                              ...customFieldValues,
                              [field.id]: e.target.value
                            })}
                          />
                        )}
                        {field.fieldType === 'date' && (
                          <Input
                            id={`custom-${field.id}`}
                            type="date"
                            value={customFieldValues[field.id] || ''}
                            onChange={(e) => setCustomFieldValues({
                              ...customFieldValues,
                              [field.id]: e.target.value
                            })}
                          />
                        )}
                        {field.fieldType === 'textarea' && (
                          <Textarea
                            id={`custom-${field.id}`}
                            value={customFieldValues[field.id] || ''}
                            onChange={(e) => setCustomFieldValues({
                              ...customFieldValues,
                              [field.id]: e.target.value
                            })}
                            rows={2}
                          />
                        )}
                        {field.fieldType === 'select' && field.options && (
                          <Select
                            value={customFieldValues[field.id] || ''}
                            onValueChange={(value) => setCustomFieldValues({
                              ...customFieldValues,
                              [field.id]: value
                            })}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccionar..." />
                            </SelectTrigger>
                            <SelectContent>
                              {JSON.parse(field.options).map((opt: string) => (
                                <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              )}
              
              {/* WhatsApp Info */}
              <Alert className="bg-green-50 border-green-200">
                <MessageCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-700">
                  <strong>Integración WhatsApp:</strong> Los leads que ingresen por WhatsApp serán marcados automáticamente con la etiqueta "Fuente: WhatsApp" y caerán en la etapa inicial "LEAD".
                </AlertDescription>
              </Alert>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setLeadDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreateLead} className="bg-emerald-600 hover:bg-emerald-700">
                Crear Lead
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog: Editar Lead */}
        <Dialog open={editLeadDialogOpen} onOpenChange={setEditLeadDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Editar Lead</DialogTitle>
              <DialogDescription>
                Modifica los datos del lead
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editFirstName">Nombre *</Label>
                  <Input
                    id="editFirstName"
                    value={leadForm.firstName}
                    onChange={(e) => setLeadForm({ ...leadForm, firstName: e.target.value })}
                    placeholder="Nombre"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editLastName">Apellido *</Label>
                  <Input
                    id="editLastName"
                    value={leadForm.lastName}
                    onChange={(e) => setLeadForm({ ...leadForm, lastName: e.target.value })}
                    placeholder="Apellido"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="editCompany">Empresa</Label>
                <Input
                  id="editCompany"
                  value={leadForm.company}
                  onChange={(e) => setLeadForm({ ...leadForm, company: e.target.value })}
                  placeholder="Nombre de la empresa"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editEmail">Email</Label>
                  <Input
                    id="editEmail"
                    type="email"
                    value={leadForm.email}
                    onChange={(e) => setLeadForm({ ...leadForm, email: e.target.value })}
                    placeholder="correo@ejemplo.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editWhatsapp">WhatsApp</Label>
                  <Input
                    id="editWhatsapp"
                    value={leadForm.whatsapp}
                    onChange={(e) => setLeadForm({ ...leadForm, whatsapp: e.target.value })}
                    placeholder="+506 0000 0000"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="editDescription">Descripción</Label>
                <Textarea
                  id="editDescription"
                  value={leadForm.description}
                  onChange={(e) => setLeadForm({ ...leadForm, description: e.target.value })}
                  placeholder="Descripción del lead o su interés"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="editSource">Fuente</Label>
                  <Select
                    value={leadForm.source}
                    onValueChange={(value) => setLeadForm({ ...leadForm, source: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="referral">Referido</SelectItem>
                      <SelectItem value="website">Sitio Web</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="other">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="editEstimatedValue">Valor Estimado ($)</Label>
                  <Input
                    id="editEstimatedValue"
                    type="number"
                    value={leadForm.estimatedValue}
                    onChange={(e) => setLeadForm({ ...leadForm, estimatedValue: e.target.value })}
                    placeholder="0"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="editNotes">Notas Adicionales</Label>
                <Textarea
                  id="editNotes"
                  value={leadForm.notes}
                  onChange={(e) => setLeadForm({ ...leadForm, notes: e.target.value })}
                  placeholder="Notas adicionales sobre el lead"
                  rows={2}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditLeadDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleEditLead} className="bg-emerald-600 hover:bg-emerald-700">
                Guardar Cambios
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog: Confirmar Pérdida */}
        <Dialog open={lostDialogOpen} onOpenChange={setLostDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <XCircle className="h-5 w-5" />
                Marcar Lead como Perdido
              </DialogTitle>
              <DialogDescription>
                Selecciona la razón por la cual se perdió este lead
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-700">
                  Lead: <strong>{pendingStageChange?.lead.firstName} {pendingStageChange?.lead.lastName}</strong>
                </AlertDescription>
              </Alert>
              
              <div className="space-y-2">
                <Label>Razón de Pérdida *</Label>
                <div className="grid grid-cols-2 gap-2">
                  {LOST_REASONS.map((reason) => (
                    <button
                      key={reason.key}
                      type="button"
                      onClick={() => setLostForm({ ...lostForm, reason: reason.key })}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        lostForm.reason === reason.key
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <span className="font-medium">{reason.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="lostNotes">Notas Adicionales</Label>
                <Textarea
                  id="lostNotes"
                  value={lostForm.notes}
                  onChange={(e) => setLostForm({ ...lostForm, notes: e.target.value })}
                  placeholder="Detalles adicionales sobre la pérdida"
                  rows={3}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setLostDialogOpen(false);
                setLostForm({ reason: '', notes: '' });
                setPendingStageChange(null);
              }}>
                Cancelar
              </Button>
              <Button 
                onClick={handleConfirmLost} 
                disabled={!lostForm.reason}
                className="bg-red-600 hover:bg-red-700"
              >
                Confirmar Pérdida
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Dialog: Ver Detalles del Lead */}
        <Dialog open={viewLeadDialogOpen} onOpenChange={setViewLeadDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detalles del Lead</DialogTitle>
            </DialogHeader>
            
            {selectedLead && (
              <div className="space-y-4">
                {/* Info Principal */}
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-semibold">
                      {selectedLead.firstName} {selectedLead.lastName}
                    </h3>
                    {selectedLead.company && (
                      <p className="text-slate-500 flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        {selectedLead.company}
                      </p>
                    )}
                  </div>
                  <Badge 
                    className="text-sm"
                    style={{ 
                      backgroundColor: `${PIPELINE_STAGES.find(s => s.key === selectedLead.stage)?.color}20`,
                      color: PIPELINE_STAGES.find(s => s.key === selectedLead.stage)?.color
                    }}
                  >
                    {PIPELINE_STAGES.find(s => s.key === selectedLead.stage)?.label}
                  </Badge>
                </div>
                
                <Separator />
                
                {/* Contacto */}
                <div className="grid grid-cols-2 gap-4">
                  {selectedLead.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-slate-400" />
                      <a href={`mailto:${selectedLead.email}`} className="text-blue-600 hover:underline">
                        {selectedLead.email}
                      </a>
                    </div>
                  )}
                  {selectedLead.whatsapp && (
                    <div className="flex items-center gap-2">
                      <MessageCircle className="h-4 w-4 text-green-500" />
                      <a 
                        href={`https://wa.me/${selectedLead.whatsapp.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-green-600 hover:underline"
                      >
                        {selectedLead.whatsapp}
                      </a>
                    </div>
                  )}
                </div>
                
                {/* Valor y Fuente */}
                <div className="grid grid-cols-2 gap-4">
                  {selectedLead.estimatedValue && (
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-emerald-500" />
                      <span className="text-emerald-600 font-medium">
                        ${selectedLead.estimatedValue.toLocaleString()}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 text-sm">Fuente:</span>
                    <Badge variant="secondary">{selectedLead.source}</Badge>
                  </div>
                </div>
                
                {/* Descripción */}
                {selectedLead.description && (
                  <div>
                    <Label className="text-slate-500 text-sm">Descripción</Label>
                    <p className="mt-1 text-slate-700">{selectedLead.description}</p>
                  </div>
                )}
                
                {/* Notas */}
                {selectedLead.notes && (
                  <div>
                    <Label className="text-slate-500 text-sm">Notas</Label>
                    <p className="mt-1 text-slate-700">{selectedLead.notes}</p>
                  </div>
                )}
                
                {/* Info de pérdida */}
                {selectedLead.stage === 'PERDIDA' && selectedLead.lostReason && (
                  <Alert className="bg-red-50 border-red-200">
                    <XCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-700">
                      <strong>Motivo de pérdida:</strong>{' '}
                      {LOST_REASONS.find(r => r.key === selectedLead.lostReason)?.label}
                      {selectedLead.lostNotes && (
                        <><br />{selectedLead.lostNotes}</>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
                
                {/* Fechas */}
                <div className="text-sm text-slate-500">
                  <p>Creado: {new Date(selectedLead.createdAt).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}</p>
                  <p>Actualizado: {new Date(selectedLead.updatedAt).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}</p>
                </div>
                
                {/* Acciones */}
                <Separator />
                <div className="flex justify-between items-center">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="text-red-600"
                    onClick={() => {
                      setViewLeadDialogOpen(false);
                      handleDeleteLead(selectedLead.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Eliminar
                  </Button>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setViewLeadDialogOpen(false);
                        handleEditLeadClick(selectedLead);
                      }}
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Editar
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-emerald-600 hover:bg-emerald-700"
                      onClick={() => {
                        setViewLeadDialogOpen(false);
                        setSelectedLead(selectedLead);
                      }}
                    >
                      Cambiar Etapa
                    </Button>
                  </div>
                </div>
                
                {/* Cambiar Etapa */}
                <div className="space-y-2">
                  <Label>Cambiar Etapa</Label>
                  <div className="flex flex-wrap gap-2">
                    {PIPELINE_STAGES.filter(s => s.key !== selectedLead.stage).map((stage) => (
                      <Button
                        key={stage.key}
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          handleStageChange(selectedLead, stage.key);
                          setViewLeadDialogOpen(false);
                        }}
                        className="text-xs"
                        style={{ borderColor: stage.color, color: stage.color }}
                      >
                        {stage.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DndContext>
  );
}
