import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PIPELINE_STAGES, LOST_REASONS } from '@/types/crm';

// POST - Importar leads desde CSV
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const projectId = formData.get('projectId') as string;
    
    if (!file || !projectId) {
      return NextResponse.json(
        { error: 'Archivo y projectId son requeridos' },
        { status: 400 }
      );
    }
    
    const text = await file.text();
    
    // Parsear CSV
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      return NextResponse.json(
        { error: 'El archivo CSV debe tener al menos una fila de encabezados y una de datos' },
        { status: 400 }
      );
    }
    
    // Función para parsear CSV (maneja comas dentro de comillas)
    const parseCSVLine = (line: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        
        if (char === '"') {
          if (inQuotes && line[i + 1] === '"') {
            current += '"';
            i++;
          } else {
            inQuotes = !inQuotes;
          }
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    };
    
    const headers = parseCSVLine(lines[0]);
    const dataLines = lines.slice(1);
    
    // Mapear índices de columnas
    const getIndex = (name: string): number => {
      const idx = headers.findIndex(h => 
        h.toLowerCase() === name.toLowerCase() ||
        h.toLowerCase().includes(name.toLowerCase())
      );
      return idx;
    };
    
    const nombreIdx = getIndex('nombre');
    const apellidoIdx = getIndex('apellido');
    const empresaIdx = getIndex('empresa');
    const emailIdx = getIndex('email');
    const whatsappIdx = getIndex('whatsapp');
    const descripcionIdx = getIndex('descripción') !== -1 ? getIndex('descripción') : getIndex('descripcion');
    const fuenteIdx = getIndex('fuente');
    const etapaIdx = getIndex('etapa');
    const valorIdx = getIndex('valor');
    const notasIdx = getIndex('notas');
    
    let imported = 0;
    let errors = 0;
    
    // Procesar cada fila
    for (const line of dataLines) {
      try {
        const values = parseCSVLine(line);
        
        // Validar datos mínimos
        const nombre = values[nombreIdx] || '';
        const apellido = values[apellidoIdx] || '';
        
        if (!nombre || !apellido) {
          errors++;
          continue;
        }
        
        // Mapear etapa
        let stage = 'LEAD';
        const etapaValue = values[etapaIdx]?.toUpperCase()?.replace(/ /g, '_') || '';
        const matchingStage = PIPELINE_STAGES.find(s => 
          s.key === etapaValue || 
          s.label.toUpperCase() === values[etapaIdx]?.toUpperCase()
        );
        if (matchingStage) {
          stage = matchingStage.key;
        }
        
        // Crear lead
        await db.lead.create({
          data: {
            projectId,
            firstName: nombre,
            lastName: apellido,
            company: values[empresaIdx] || null,
            email: values[emailIdx] || null,
            whatsapp: values[whatsappIdx] || null,
            description: values[descripcionIdx] || null,
            source: values[fuenteIdx] || 'import',
            stage,
            estimatedValue: values[valorIdx] ? parseFloat(values[valorIdx]) : null,
            notes: values[notasIdx] || null,
          }
        });
        
        imported++;
      } catch {
        errors++;
      }
    }
    
    return NextResponse.json({
      success: true,
      imported,
      errors,
      total: dataLines.length
    });
  } catch (error) {
    console.error('Error importing leads:', error);
    return NextResponse.json(
      { error: 'Error al importar leads' },
      { status: 500 }
    );
  }
}
