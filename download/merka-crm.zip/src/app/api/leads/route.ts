import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import type { CreateLeadInput } from '@/types/crm';

// GET - Listar leads (con filtros)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const stage = searchParams.get('stage');
    const search = searchParams.get('search');
    
    if (!projectId) {
      return NextResponse.json(
        { error: 'projectId es requerido' },
        { status: 400 }
      );
    }
    
    const where: Record<string, unknown> = { projectId };
    
    if (stage && stage !== 'all') {
      where.stage = stage;
    }
    
    if (search) {
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { company: { contains: search } },
        { email: { contains: search } },
      ];
    }
    
    const leads = await db.lead.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        customFieldValues: {
          include: {
            customField: true
          }
        }
      }
    });
    
    return NextResponse.json(leads);
  } catch (error) {
    console.error('Error fetching leads:', error);
    return NextResponse.json(
      { error: 'Error al obtener leads' },
      { status: 500 }
    );
  }
}

// POST - Crear nuevo lead
export async function POST(request: NextRequest) {
  try {
    const body: CreateLeadInput = await request.json();
    const { 
      projectId, 
      firstName, 
      lastName, 
      company, 
      email, 
      whatsapp, 
      description,
      source = 'manual',
      sourceDetails,
      estimatedValue,
      notes,
      customFields 
    } = body;
    
    if (!projectId || !firstName || !lastName) {
      return NextResponse.json(
        { error: 'Proyecto, nombre y apellido son requeridos' },
        { status: 400 }
      );
    }
    
    // Crear el lead
    const lead = await db.lead.create({
      data: {
        projectId,
        firstName,
        lastName,
        company,
        email,
        whatsapp,
        description,
        source,
        sourceDetails,
        estimatedValue,
        notes,
        stage: 'LEAD',
        customFieldValues: customFields && customFields.length > 0 ? {
          create: customFields.map(cf => ({
            customFieldId: cf.fieldId,
            value: cf.value
          }))
        } : undefined
      },
      include: {
        customFieldValues: {
          include: {
            customField: true
          }
        }
      }
    });
    
    // Crear actividad inicial
    await db.activity.create({
      data: {
        leadId: lead.id,
        type: 'note',
        description: `Lead creado desde fuente: ${source}`,
        metadata: JSON.stringify({ source, sourceDetails })
      }
    });
    
    return NextResponse.json(lead, { status: 201 });
  } catch (error) {
    console.error('Error creating lead:', error);
    return NextResponse.json(
      { error: 'Error al crear lead' },
      { status: 500 }
    );
  }
}
