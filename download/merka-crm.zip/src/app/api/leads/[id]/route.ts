import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import type { UpdateLeadInput, LostReason } from '@/types/crm';

// GET - Obtener un lead específico
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const lead = await db.lead.findUnique({
      where: { id },
      include: {
        customFieldValues: {
          include: {
            customField: true
          }
        },
        activities: {
          orderBy: { createdAt: 'desc' },
          take: 50
        }
      }
    });
    
    if (!lead) {
      return NextResponse.json(
        { error: 'Lead no encontrado' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(lead);
  } catch (error) {
    console.error('Error fetching lead:', error);
    return NextResponse.json(
      { error: 'Error al obtener lead' },
      { status: 500 }
    );
  }
}

// PUT - Actualizar un lead
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body: UpdateLeadInput = await request.json();
    
    const existingLead = await db.lead.findUnique({
      where: { id }
    });
    
    if (!existingLead) {
      return NextResponse.json(
        { error: 'Lead no encontrado' },
        { status: 404 }
      );
    }
    
    // Si se está moviendo a PERDIDA, registrar fecha y razón
    let updateData: Record<string, unknown> = { ...body };
    
    if (body.stage === 'PERDIDA' && existingLead.stage !== 'PERDIDA') {
      updateData.lostAt = new Date();
    }
    
    // Si se mueve de PERDIDA a otra etapa, limpiar datos de pérdida
    if (body.stage && body.stage !== 'PERDIDA' && existingLead.stage === 'PERDIDA') {
      updateData.lostReason = null;
      updateData.lostNotes = null;
      updateData.lostAt = null;
    }
    
    // Actualizar lead
    const lead = await db.lead.update({
      where: { id },
      data: updateData,
      include: {
        customFieldValues: {
          include: {
            customField: true
          }
        }
      }
    });
    
    // Registrar actividad de cambio de etapa
    if (body.stage && body.stage !== existingLead.stage) {
      await db.activity.create({
        data: {
          leadId: id,
          type: 'stage_change',
          description: `Etapa cambiada de ${existingLead.stage} a ${body.stage}`,
          metadata: JSON.stringify({
            fromStage: existingLead.stage,
            toStage: body.stage,
            lostReason: body.lostReason
          })
        }
      });
    }
    
    return NextResponse.json(lead);
  } catch (error) {
    console.error('Error updating lead:', error);
    return NextResponse.json(
      { error: 'Error al actualizar lead' },
      { status: 500 }
    );
  }
}

// DELETE - Eliminar un lead
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.lead.delete({
      where: { id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting lead:', error);
    return NextResponse.json(
      { error: 'Error al eliminar lead' },
      { status: 500 }
    );
  }
}

// PATCH - Actualizar etapa del lead (para drag & drop)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { stage, lostReason, lostNotes } = body;
    
    const existingLead = await db.lead.findUnique({
      where: { id }
    });
    
    if (!existingLead) {
      return NextResponse.json(
        { error: 'Lead no encontrado' },
        { status: 404 }
      );
    }
    
    // Si se mueve a PERDIDA, validar razón
    if (stage === 'PERDIDA' && !lostReason) {
      return NextResponse.json(
        { error: 'Se requiere especificar la razón de pérdida' },
        { status: 400 }
      );
    }
    
    let updateData: Record<string, unknown> = { stage };
    
    if (stage === 'PERDIDA') {
      updateData.lostReason = lostReason as LostReason;
      updateData.lostNotes = lostNotes;
      updateData.lostAt = new Date();
    }
    
    const lead = await db.lead.update({
      where: { id },
      data: updateData
    });
    
    // Registrar actividad
    await db.activity.create({
      data: {
        leadId: id,
        type: 'stage_change',
        description: `Etapa cambiada de ${existingLead.stage} a ${stage}`,
        metadata: JSON.stringify({
          fromStage: existingLead.stage,
          toStage: stage,
          lostReason
        })
      }
    });
    
    return NextResponse.json(lead);
  } catch (error) {
    console.error('Error updating lead stage:', error);
    return NextResponse.json(
      { error: 'Error al actualizar etapa' },
      { status: 500 }
    );
  }
}
