import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// DELETE - Eliminar campo personalizado
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; fieldId: string }> }
) {
  try {
    const { id, fieldId } = await params;
    
    // Eliminar todos los valores asociados primero
    await db.leadCustomFieldValue.deleteMany({
      where: { customFieldId: fieldId }
    });
    
    // Eliminar el campo
    await db.customField.delete({
      where: { 
        id: fieldId,
        projectId: id 
      }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting custom field:', error);
    return NextResponse.json(
      { error: 'Error al eliminar campo personalizado' },
      { status: 500 }
    );
  }
}
