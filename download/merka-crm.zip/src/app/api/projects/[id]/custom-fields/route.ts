import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Obtener campos personalizados del proyecto
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const customFields = await db.customField.findMany({
      where: { projectId: id },
      orderBy: { order: 'asc' }
    });
    
    return NextResponse.json(customFields);
  } catch (error) {
    console.error('Error fetching custom fields:', error);
    return NextResponse.json(
      { error: 'Error al obtener campos personalizados' },
      { status: 500 }
    );
  }
}

// POST - Crear campo personalizado
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, fieldType, options, required } = body;
    
    if (!name || !fieldType) {
      return NextResponse.json(
        { error: 'Nombre y tipo de campo son requeridos' },
        { status: 400 }
      );
    }
    
    // Verificar si ya existe
    const existing = await db.customField.findFirst({
      where: { projectId: id, name }
    });
    
    if (existing) {
      return NextResponse.json(
        { error: 'Ya existe un campo con ese nombre' },
        { status: 400 }
      );
    }
    
    // Obtener el máximo orden
    const maxOrder = await db.customField.findFirst({
      where: { projectId: id },
      orderBy: { order: 'desc' },
      select: { order: true }
    });
    
    const customField = await db.customField.create({
      data: {
        projectId: id,
        name,
        fieldType,
        options: options ? JSON.stringify(options) : null,
        required: required || false,
        order: (maxOrder?.order || 0) + 1
      }
    });
    
    return NextResponse.json(customField, { status: 201 });
  } catch (error) {
    console.error('Error creating custom field:', error);
    return NextResponse.json(
      { error: 'Error al crear campo personalizado' },
      { status: 500 }
    );
  }
}
