import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PIPELINE_STAGES, LOST_REASONS } from '@/types/crm';

// GET - Exportar leads a CSV
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    
    if (!projectId) {
      return NextResponse.json(
        { error: 'projectId es requerido' },
        { status: 400 }
      );
    }
    
    const leads = await db.lead.findMany({
      where: { projectId },
      include: {
        customFieldValues: {
          include: {
            customField: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    // Obtener campos personalizados del proyecto
    const customFields = await db.customField.findMany({
      where: { projectId },
      orderBy: { order: 'asc' }
    });
    
    // Headers base
    const baseHeaders = [
      'ID',
      'Nombre',
      'Apellido',
      'Empresa',
      'Email',
      'WhatsApp',
      'Descripción',
      'Fuente',
      'Etapa',
      'Razón Pérdida',
      'Notas Pérdida',
      'Valor Estimado',
      'Notas',
      'Último Contacto',
      'Próximo Seguimiento',
      'Fecha Creación',
      'Fecha Actualización'
    ];
    
    // Añadir headers de campos personalizados
    const customHeaders = customFields.map(cf => cf.name);
    const allHeaders = [...baseHeaders, ...customHeaders];
    
    // Función para escapar CSV
    const escapeCSV = (value: unknown): string => {
      if (value === null || value === undefined) return '';
      const str = String(value);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };
    
    // Generar filas
    const rows = leads.map(lead => {
      const stageLabel = PIPELINE_STAGES.find(s => s.key === lead.stage)?.label || lead.stage;
      const lostReasonLabel = lead.lostReason 
        ? LOST_REASONS.find(r => r.key === lead.lostReason)?.label || lead.lostReason
        : '';
      
      // Crear mapa de valores de campos personalizados
      const customValuesMap = new Map(
        lead.customFieldValues?.map(cfv => [cfv.customFieldId, cfv.value]) || []
      );
      
      const baseRow = [
        escapeCSV(lead.id),
        escapeCSV(lead.firstName),
        escapeCSV(lead.lastName),
        escapeCSV(lead.company),
        escapeCSV(lead.email),
        escapeCSV(lead.whatsapp),
        escapeCSV(lead.description),
        escapeCSV(lead.source),
        escapeCSV(stageLabel),
        escapeCSV(lostReasonLabel),
        escapeCSV(lead.lostNotes),
        escapeCSV(lead.estimatedValue),
        escapeCSV(lead.notes),
        escapeCSV(lead.lastContactAt),
        escapeCSV(lead.nextFollowUpAt),
        escapeCSV(lead.createdAt),
        escapeCSV(lead.updatedAt)
      ];
      
      // Añadir valores de campos personalizados
      const customRow = customFields.map(cf => {
        const value = customValuesMap.get(cf.id) || '';
        return escapeCSV(value);
      });
      
      return [...baseRow, ...customRow].join(',');
    });
    
    // Construir CSV
    const csv = [
      allHeaders.map(escapeCSV).join(','),
      ...rows
    ].join('\n');
    
    // Agregar BOM para Excel
    const bom = '\uFEFF';
    const csvWithBom = bom + csv;
    
    return new NextResponse(csvWithBom, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="merka-leads-${new Date().toISOString().split('T')[0]}.csv"`
      }
    });
  } catch (error) {
    console.error('Error exporting leads:', error);
    return NextResponse.json(
      { error: 'Error al exportar leads' },
      { status: 500 }
    );
  }
}
